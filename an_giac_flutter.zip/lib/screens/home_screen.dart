import 'package:flutter/material.dart';
import '../utils/calc.dart';
import '../models/wellness_entry.dart';
import '../services/storage.dart';
import '../widgets/animated_mood_icon.dart';
import 'result_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _sweet = 0;
  int _stress = 0;
  TimeOfDay? _sleep;
  TimeOfDay? _wake;
  final _notesCtrl = TextEditingController();
  final _storage = StorageService();

  Future<void> _pickTime({required bool isSleep}) async {
    final picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
      helpText: isSleep ? 'Chọn giờ đi ngủ' : 'Chọn giờ thức dậy',
    );
    if (picked != null) {
      setState(() {
        if (isSleep) {
          _sleep = picked;
        } else {
          _wake = picked;
        }
      });
    }
  }

  int _toMinutes(TimeOfDay t) => t.hour * 60 + t.minute;

  Future<void> _computeAndSave() async {
    if (_sleep == null || _wake == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Vui lòng chọn giờ ngủ và giờ dậy')),
      );
      return;
    }
    final sleepMin = _toMinutes(_sleep!);
    final wakeMin = _toMinutes(_wake!);
    final hours = CalcUtils.hoursBetween(sleepMin, wakeMin);
    final score = CalcUtils.computeScore(
      sweetUnits: _sweet,
      stressLevel: _stress,
      hoursSlept: hours,
    );

    final entry = WellnessEntry(
      date: DateTime.now(),
      sweetUnits: _sweet,
      stressLevel: _stress,
      sleepMinutes: sleepMin,
      wakeMinutes: wakeMin,
      hoursSlept: hours,
      score: score,
      notes: _notesCtrl.text.isEmpty ? null : _notesCtrl.text.trim(),
    );

    await _storage.addEntry(entry);

    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => ResultScreen(entry: entry)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('An Giấc'),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF6C63FF), Color(0xFF8E97FD)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Card(
                  elevation: 0,
                  color: Colors.white.withOpacity(0.9),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Expanded(
                              child: Text(
                                "Hôm nay bạn thấy thế nào?",
                                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                              ),
                            ),
                            AnimatedMoodIcon(score: (100 - (_sweet*5 + _stress*3)).clamp(0, 100)),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Text("Lượng đồ ngọt: $_sweet / 10"),
                        Slider(
                          value: _sweet.toDouble(),
                          min: 0,
                          max: 10,
                          divisions: 10,
                          label: "$_sweet",
                          onChanged: (v) => setState(() => _sweet = v.round()),
                        ),
                        const SizedBox(height: 8),
                        Text("Mức độ stress: $_stress / 10"),
                        Slider(
                          value: _stress.toDouble(),
                          min: 0,
                          max: 10,
                          divisions: 10,
                          label: "$_stress",
                          onChanged: (v) => setState(() => _stress = v.round()),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: ElevatedButton.icon(
                                onPressed: () => _pickTime(isSleep: true),
                                icon: const Icon(Icons.bedtime),
                                label: Text(_sleep == null ? "Giờ ngủ" : "Ngủ: ${_sleep!.format(context)}"),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: ElevatedButton.icon(
                                onPressed: () => _pickTime(isSleep: false),
                                icon: const Icon(Icons.wb_sunny_outlined),
                                label: Text(_wake == null ? "Giờ dậy" : "Dậy: ${_wake!.format(context)}"),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: _notesCtrl,
                          decoration: const InputDecoration(
                            labelText: "Ghi chú (tùy chọn)",
                            border: OutlineInputBorder(),
                          ),
                          maxLines: 2,
                        ),
                        const SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton(
                            onPressed: _computeAndSave,
                            child: const Padding(
                              padding: EdgeInsets.symmetric(vertical: 12),
                              child: Text("Tính & Lưu hôm nay"),
                            ),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          "Lưu ý: Chỉ số An Giấc chỉ mang tính tham khảo, không thay thế tư vấn y khoa.",
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/contact.dart';
import '../services/storage.dart';

class EmergencyScreen extends StatefulWidget {
  const EmergencyScreen({super.key});

  @override
  State<EmergencyScreen> createState() => _EmergencyScreenState();
}

class _EmergencyScreenState extends State<EmergencyScreen> {
  final _storage = StorageService();
  late Future<List<EmergencyContact>> _future;

  @override
  void initState() {
    super.initState();
    _future = _storage.loadContacts();
  }

  Future<void> _refresh() async {
    setState(() {
      _future = _storage.loadContacts();
    });
  }

  Future<void> _addContactDialog() async {
    final nameCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Thêm liên hệ'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(decoration: const InputDecoration(labelText: 'Tên'), controller: nameCtrl),
            const SizedBox(height: 8),
            TextField(decoration: const InputDecoration(labelText: 'Số điện thoại'), controller: phoneCtrl, keyboardType: TextInputType.phone),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Hủy')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Lưu')),
        ],
      ),
    );
    if (ok == true && nameCtrl.text.trim().isNotEmpty && phoneCtrl.text.trim().isNotEmpty) {
      await _storage.addContact(EmergencyContact(name: nameCtrl.text.trim(), phone: phoneCtrl.text.trim()));
      await _refresh();
    }
  }

  Future<void> _call(String phone) async {
    final uri = Uri(scheme: 'tel', path: phone);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Không thể mở trình gọi điện.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Liên hệ khẩn cấp')),
      floatingActionButton: FloatingActionButton(
        onPressed: _addContactDialog,
        child: const Icon(Icons.add_call),
      ),
      body: FutureBuilder<List<EmergencyContact>>(
        future: _future,
        builder: (context, snapshot) {
          final data = snapshot.data ?? [];
          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: data.length + 1,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              if (index == 0) {
                return Card(
                  color: Theme.of(context).colorScheme.secondaryContainer,
                  child: const ListTile(
                    leading: Icon(Icons.info_outline),
                    title: Text('Lưu ý'),
                    subtitle: Text('Vui lòng nhập các số liên lạc đáng tin cậy (gia đình, bác sĩ). Tính năng này chỉ hỗ trợ quay số điện thoại trên thiết bị của bạn.'),
                  ),
                );
              }
              final c = data[index - 1];
              return Dismissible(
                key: ValueKey("${c.name}-${c.phone}-$index"),
                background: Container(
                  decoration: BoxDecoration(
                    color: Colors.red.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 16),
                  child: const Icon(Icons.delete, color: Colors.red),
                ),
                direction: DismissDirection.endToStart,
                confirmDismiss: (_) async {
                  return await showDialog<bool>(
                        context: context,
                        builder: (ctx) => AlertDialog(
                          title: const Text("Xóa liên hệ?"),
                          content: Text("Bạn có chắc muốn xóa '${c.name}'?"),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text("Hủy")),
                            TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text("Xóa")),
                          ],
                        ),
                      ) ?? false;
                },
                onDismissed: (_) async {
                  await _storage.deleteContactAt(index - 1);
                  await _refresh();
                },
                child: ListTile(
                  tileColor: Theme.of(context).colorScheme.surface,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  leading: CircleAvatar(child: Text(c.name.isNotEmpty ? c.name[0].toUpperCase() : '?')),
                  title: Text(c.name),
                  subtitle: Text(c.phone),
                  trailing: IconButton(
                    icon: const Icon(Icons.call),
                    onPressed: () => _call(c.phone),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

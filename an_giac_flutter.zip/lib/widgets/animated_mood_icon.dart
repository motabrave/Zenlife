import 'package:flutter/material.dart';

class AnimatedMoodIcon extends StatefulWidget {
  final int score;
  final double size;
  final bool pulse;

  const AnimatedMoodIcon({
    super.key,
    required this.score,
    this.size = 72,
    this.pulse = true,
  });

  @override
  State<AnimatedMoodIcon> createState() => _AnimatedMoodIconState();
}

class _AnimatedMoodIconState extends State<AnimatedMoodIcon>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
      lowerBound: 0.95,
      upperBound: 1.05,
    );
    _scale = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    if (widget.pulse) {
      _controller.repeat(reverse: true);
    }
  }

  @override
  void didUpdateWidget(covariant AnimatedMoodIcon oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.pulse != widget.pulse) {
      if (widget.pulse) {
        _controller.repeat(reverse: true);
      } else {
        _controller.stop();
      }
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final (iconData, color) = _iconForScore(widget.score);

    return ScaleTransition(
      scale: _scale,
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 400),
        transitionBuilder: (child, anim) =>
            ScaleTransition(scale: anim, child: child),
        child: Icon(
          iconData,
          key: ValueKey(iconData.codePoint + widget.score),
          color: color,
          size: widget.size,
        ),
      ),
    );
  }

  (IconData, Color) _iconForScore(int score) {
    if (score >= 80) {
      return (Icons.sentiment_very_satisfied, Colors.green);
    } else if (score >= 50) {
      return (Icons.sentiment_neutral, Colors.amber);
    } else {
      return (Icons.sentiment_dissatisfied, Colors.redAccent);
    }
  }
}
